<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Fournisseur extends CI_Controller {

	public function index()
	{
/* ################### page :: methode pour lister ################### */
		if($_SESSION['id']!==NULL){
		$data['fournisseurs'] = $this->M_fournisseur->getFournisseur();

		$data['titre'] = $this->lang->line('affich_four');
		$this->load->view('fournisseur/liste', $data);
		}else{
				redirect('admin/administrateur');
						}
	}

	public function ajouter()
	{
/* ################### page :: methode pour ajouter ################### */	
if($_SESSION['id']!==NULL){	
		$data['action']='admin/fournisseur/ajouter';
		$data['submit']=$this->lang->line('AJOUTER');
		$data['titre'] = $this->lang->line('ajouter_four');
		$data['fours']=$this->M_fournisseur->getFournisseur();
		$this->form_validation->set_rules('nomfour', 'lang:nomfour', 'trim|required');
		$this->form_validation->set_rules('prenomfour', 'lang:prenomfour', 'trim|required');
		$this->form_validation->set_rules('villefour', 'lang:villefour', 'trim|required');
		$this->form_validation->set_rules('sexefour', 'lang:sexefour', 'trim|required');
		$this->form_validation->set_rules('emailfour', 'lang:emailfour', 'trim|required|valid_email');
		$this->form_validation->set_rules('mdpfour', 'lang:mdpfour', 'trim|required|is_unique[fournisseur.mdpfour]|min_length[6]');
		$this->form_validation->set_rules('cmdp', 'lang:mdpfour', 'trim|required|matches[mdpfour]');
		$this->form_validation->set_rules('telephonefour', 'lang:telephonecl', 'trim|required|min_length[9]|max_length[12]|numeric');
		if($this->form_validation->run())
		{
			$mdp=$this->input->post('mdpfour');
			$four = array(
				'nomfour' => $this->input->post('nomfour'),
				'prenomfour' => $this->input->post('prenomfour'),
				'datenaissfour' => $this->input->post('datenaissfour'),
				'villefour' => $this->input->post('villefour'),
				'sexefour' => $this->input->post('sexefour'),
				'emailfour' => $this->input->post('emailfour'),
				'mdpfour' => password_hash($mdp,PASSWORD_DEFAULT),
				'telephonefour' => $this->input->post('telephonefour'),
				'statutfour' => $this->input->post('statutfour'),
				'quartierfour' => $this->input->post('quartierfour'),
				'datesavefour' => date('Y-m-d'),
				'dateupdatefour' => date('Y-m-d'),
			);

			if($this->M_fournisseur->addFournisseur($four))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('admin/fournisseur/ajouter');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/fournisseur/ajouter');
			}
		}

		$data['titre'] = $this->lang->line('ajouter_four');
		$this->load->view('fournisseur/ajouter', $data);
		}else{
				redirect('admin/administrateur');
						}
	}

	public function modifier($idfour)
	{
		if($_SESSION['id']!==NULL){
		$data['action']='admin/fournisseur/modifier/'.$idfour;
		$data['submit']=$this->lang->line('MODIFIER');
		$data['titre'] = $this->lang->line('modif_four');
		$ros=$data['fours']=$this->M_fournisseur->getFournisseur(array('idfour'=>$idfour));
		print_r($ros);
		//print_r($data['fours']);
		$this->form_validation->set_rules('nomfour', 'lang:nomfour', 'required');
		$this->form_validation->set_rules('prenomfour', 'lang:prenomfour', 'required');
		$this->form_validation->set_rules('villefour', 'lang:villefour', 'required');
		$this->form_validation->set_rules('sexefour', 'lang:sexefour', 'required');
		//$this->form_validation->set_rules('emailfour', 'lang:emailfour', 'required|is-unique[fournisseur.emailfour]|valid_email');
		$this->form_validation->set_rules('mdpfour', 'lang:mdpfour', 'required|is_unique[fournisseur.mdpfour]|min_length[6]');
		$this->form_validation->set_rules('cmdp', 'lang:mdpfour', 'required|matches[mdpfour]');
		$this->form_validation->set_rules('telephonefour', 'lang:telephonefour', 'required|min_length[9]');
		if($this->form_validation->run())
		{
			foreach ($ros as $v) {
					$v->dateupdatefour;
				}
			$mdp=$this->input->post('mdpfour');
			$four = array(
				'idfour' => $idfour,
				'nomfour' => $this->input->post('nomfour'),
				'prenomfour' => $this->input->post('prenomfour'),
				'datenaissfour' => $this->input->post('datenaissfour'),
				'villefour' => $this->input->post('villefour'),
				'sexefour' => $this->input->post('sexefour'),
				'emailfour' => $this->input->post('emailfour'),
				'mdpfour' => password_hash($mdp,PASSWORD_DEFAULT),
				'telephonefour' => $this->input->post('telephonefour'),
				'statutfour' => $this->input->post('statutfour'),
				'quartierfour' => $this->input->post('quartierfour'),
				'datesavefour' => date('Y-m-d'),
				'dateupdatefour' => $v->dateupdatefour,
			);

			if($this->M_fournisseur->updateFournisseur($four))
			{
				$this->session->set_flashdata('success', 'information enregistrée');
				redirect('admin/fournisseur/');
			} else {
				$this->session->set_flashdata('warning', 'un problème est survenu pendant dans la bd');
				redirect('admin/fournisseur/ajouter');
			}
		}
		$this->load->view('fournisseur/ajouter', $data);
		}else{
				redirect('admin/administrateur');
						}
	}

	public function detail()
	{

	}
}