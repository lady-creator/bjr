<?php 

defined('BASEPATH') OR exit('No direct script access allowed');

class createpdf extends CI_Controller {

function pdf()
{
    $this->load->helper('pdf_helper');
    /*
        ---- ---- ---- ----
        your code here
        ---- ---- ---- ----
    */
        $data['l']='hello';
    $this->load->view('pdfreport', $data);
}
public function panier()
		{
			$data['titre'] = 'planG';
			$this->load->view('panier',$data);
		} 

}

